from django.contrib import admin
from .models import Category, Product, Client, Order, ProductAdmin, ClientAdmin

# Register your models here.
admin.site.register(Category)
admin.site.register(Product)
admin.site.register(Client)
admin.site.register(Order)
admin.site.register(ProductAdmin)
admin.site.register(ClientAdmin)

